<?php
namespace Drupal\page_json\Controller;
use Drupal\Core\Cache\CacheableMetadata;
use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Routing\RouteMatchInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Symfony\Component\HttpKernel\Exception\HttpException;
use Drupal\node\NodeInterface;
use Symfony\Component\HttpFoundation\JsonResponse;
/**
 * Controller routines for page_json routes.
 */
class PageJsonController extends ControllerBase {
	
	/**
   * Prints a page listing general help for a module.
   *
   * @param string $sitekey
   *   A siteapikey from configuration
   
   * @param string $nid
   *   A node id from the url
   *
   * @return json output
   *   A render array as expected by
   *   \Drupal\Core\Render\RendererInterface::render().
   *
   * @throws \Symfony\Component\HttpKernel\Exception\NotFoundHttpException
   */
     

  public function displayJson() {
	  return [
      '#type' => 'markup',
      '#markup' => $this->t('Hello, World!'),
    ];
  }
  /*
  Prints a page listing general help for a module.
   *
   * @param string $key
   *   A siteapikey from configuration
   
   * @param string $node
   *   A node id from the url
   *
   * @return json output
   *   A render array as expected by
   *   Symfony\Component\HttpFoundation\JsonResponse.
   *
   * @throws \Symfony\Component\HttpKernel\Exception\HttpException
  */
  public function displayJsonNode($key,$node)
  {
	  $config_factory = \Drupal::configFactory();
	
	  $config  = $config_factory->getEditable('page_json.siteapikey');
		if($config->get('siteapikey') == $key)
		{
			  $noderesponse = node_load($node);
			  
			if($noderesponse)
			{
				$nodearry = array("title"=>$noderesponse->getTitle(),"type"=>$noderesponse->getType(),"nid"=>$node);
				return new JsonResponse($nodearry);
			}
			else
				return new JsonResponse(array('message'=>"No records found"));
			exit;
	  }
	  else
	  {
		  return new JsonResponse(array('error'=>"Access Denied"));
			exit;
	  }
  }
}